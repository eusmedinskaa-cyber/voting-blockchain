"""
Мини-блокчейн для голосования.
Список кандидатов хранится в IPFS (в блоке записан только CID).
"""
import hashlib
import json
import time

# ВСТАВЬТЕ СЮДА СВОЙ CID ИЗ IPFS (результат команды `ipfs add`)
CANDIDATES_CID = "QmВашCID"

DIFFICULTY = 3  # хеш блока должен начинаться с трёх нулей (Proof of Work)


class Block:
    """Один блок цепочки."""

    def __init__(self, index, votes, prev_hash):
        self.index = index
        self.votes = votes            # список голосов
        self.timestamp = time.time()
        self.prev_hash = prev_hash    # хеш предыдущего блока (так блоки "склеены")
        self.nonce = 0                # число, которое подбирает майнер
        self.hash = self.calc_hash()

    def calc_hash(self):
        data = json.dumps(
            [self.index, self.votes, self.timestamp, self.prev_hash, self.nonce],
            sort_keys=True,
        )
        return hashlib.sha256(data.encode()).hexdigest()

    def mine(self):
        """Proof of Work: подбираем nonce, пока хеш не начнётся с нулей."""
        while not self.hash.startswith("0" * DIFFICULTY):
            self.nonce += 1
            self.hash = self.calc_hash()


class Blockchain:
    """Цепочка блоков + правила голосования."""

    def __init__(self, candidates, candidates_cid):
        self.candidates = candidates
        genesis = Block(0, [{"candidates_cid": candidates_cid}], "0")
        genesis.mine()
        self.chain = [genesis]   # первый (генезис) блок хранит CID из IPFS
        self.pending = []        # голоса, ещё не попавшие в блок
        self.voters = set()      # кто уже проголосовал

    def add_vote(self, voter_id, candidate):
        if candidate not in self.candidates:
            raise ValueError(f"Нет такого кандидата: {candidate}")
        if voter_id in self.voters:
            raise ValueError(f"{voter_id} уже голосовал (повторный голос запрещён)")
        self.voters.add(voter_id)
        # храним хеш имени, а не имя: так голос анонимнее
        voter_hash = hashlib.sha256(voter_id.encode()).hexdigest()[:16]
        self.pending.append({"voter": voter_hash, "candidate": candidate})

    def mine_pending(self):
        """Собираем ожидающие голоса в новый блок и добавляем в цепочку."""
        if not self.pending:
            return
        block = Block(len(self.chain), self.pending, self.chain[-1].hash)
        block.mine()
        self.chain.append(block)
        self.pending = []

    def is_valid(self):
        """Проверка: никто не менял старые блоки."""
        for i in range(1, len(self.chain)):
            cur, prev = self.chain[i], self.chain[i - 1]
            if cur.hash != cur.calc_hash():
                return False   # содержимое блока изменили
            if cur.prev_hash != prev.hash:
                return False   # склейка порвана
        return True

    def tally(self):
        """Подсчёт голосов."""
        result = {c: 0 for c in self.candidates}
        for block in self.chain[1:]:
            for vote in block.votes:
                result[vote["candidate"]] += 1
        return result


def show_chain(bc):
    for b in bc.chain:
        print(f"  Блок {b.index}: hash={b.hash[:16]}...  prev={b.prev_hash[:16]}...  голосов={len(b.votes)}")


if __name__ == "__main__":
    bc = Blockchain(candidates=["Alice", "Bob"], candidates_cid=CANDIDATES_CID)

    print("=== 1. Голосование ===")
    bc.add_vote("ivanov", "Alice")
    bc.add_vote("petrov", "Bob")
    bc.add_vote("sidorov", "Alice")
    bc.mine_pending()
    bc.add_vote("kuznetsov", "Bob")
    bc.add_vote("smirnov", "Alice")
    bc.mine_pending()
    show_chain(bc)

    print("\n=== 2. Итоги ===")
    print(" ", bc.tally())
    print("  Цепочка валидна:", bc.is_valid())

    print("\n=== 3. Попытка проголосовать дважды ===")
    try:
        bc.add_vote("ivanov", "Bob")
    except ValueError as e:
        print("  Ошибка:", e)

    print("\n=== 4. Попытка подделать голос в блоке 1 ===")
    bc.chain[1].votes[0]["candidate"] = "Bob"
    print("  Цепочка валидна:", bc.is_valid(), "<- подделка обнаружена")
